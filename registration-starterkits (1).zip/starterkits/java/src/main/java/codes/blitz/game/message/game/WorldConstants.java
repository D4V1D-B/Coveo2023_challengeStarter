package codes.blitz.game.message.game;

public record WorldConstants(int width, int height) {
}