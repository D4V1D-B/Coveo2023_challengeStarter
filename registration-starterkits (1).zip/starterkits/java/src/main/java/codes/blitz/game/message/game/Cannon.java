package codes.blitz.game.message.game;

public record Cannon(Vector position, double orientation, int cooldown) {
}