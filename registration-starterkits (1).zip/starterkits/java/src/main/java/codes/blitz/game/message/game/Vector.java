package codes.blitz.game.message.game;

public record Vector(double x, double y) {
}