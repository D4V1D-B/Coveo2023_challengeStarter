package codes.blitz.game.message.game;

public record ExplosionInfos(MeteorType meteorType, double approximateAngle) {
}