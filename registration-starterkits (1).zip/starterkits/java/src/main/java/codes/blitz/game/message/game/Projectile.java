package codes.blitz.game.message.game;

public record Projectile(String id, Vector position, Vector velocity, double size) {
}