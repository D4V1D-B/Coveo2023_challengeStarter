package codes.blitz.game.message.game;

public enum MeteorType {
    LARGE,
    MEDIUM,
    SMALL
}