package codes.blitz.game.message.game;

public record RocketsConstants(double speed, double size) {
}