package codes.blitz.game.message;

public enum MessageType
{
    COMMAND,
    REGISTER
}
